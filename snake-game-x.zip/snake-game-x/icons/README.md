# Snake Game X icon pack

All files are PNG unless noted. Sizes are common recommendations; platforms change them,
so check the current upload guidance if one rejects a file.

## browser/  (tab icons, linked from index.html)
favicon-16, 32, 48, 64. `icons/favicon.ico` bundles 16, 32 and 48.

## apps/  (home screen, PWA, Windows, desktop)
- apple-touch-icon-120 / 152 / 167 / 180: iOS and iPadOS home screen (square, the OS rounds it)
- android-chrome-192 / 512: Android and PWA install icons
- maskable-192 / 512: full-bleed art with a safe zone, for adaptive icons
- mstile-70 / 150 / 310: Windows tiles
- app-icon-128 / 256 / 1024: desktop apps and stores

## profile/  (profile pictures and small icons)
- scratch-profile-500: Scratch profile picture (square)
- scratch-sprite-96: small Scratch sprite or costume icon
- penguinmod-profile-500: PenguinMod profile picture (square)
- penguinmod-extension-icon-64: small icon for a PenguinMod extension or menu
- youtube-channel-800: YouTube channel icon (800x800, shown as a circle)
- youtube-channel-98-round: pre-rounded copy at YouTube's smallest display size
- discord-server-512, discord-bot-128-round, github-avatar-500, twitter-x-400,
  twitch-256, steam-avatar-184, slack-512
- round-512: circular icon for any place that wants a round image

## thumbnails/  (wide images)
- scratch-penguinmod-project-480x360: project thumbnail (4:3)
- youtube-thumbnail-1280x720
- social-share-og-1200x630: link preview image (linked from index.html)
- itchio-cover-630x500

## Source art (SVG, scalable)
icon-rounded.svg, icon-full.svg, icon-round.svg, icon-avatar.svg
